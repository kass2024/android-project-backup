#!/bin/bash
set -e

DATE=$(date +%Y%m%d%H%M)

BASE_PATH=`pwd`

SERVER_NAME=hf-tcp-gateway-service

PROFILES_ACTIVE=default

HEALTH_CHECK_URL=http://127.0.0.1:8190/api/test

HEAP_ERROR_PATH=$BASE_PATH/heapError

JAVA_OPS="-Xms512m -Xmx512m -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$HEAP_ERROR_PATH"

function stop() {
    echo "[stop] start stop $BASE_PATH/$SERVER_NAME"
    PID=$(ps -ef | grep $BASE_PATH/$SERVER_NAME | grep -v "grep" | awk '{print $2}')
    if [ -n "$PID" ]; then
	echo "[stop] $BASE_PATH/$SERVER_NAME running, start kill [$PID]"
	kill -15 $PID
	for ((i = 0; i < 120; i++))
	    do
		sleep 1
		PID=$(ps -ef | grep $BASE_PATH/$SERVER_NAME | grep -v "grep" | awk '{print $2}')
		if [ -n "$PID" ]; then
		    echo -e ".\c"
		else
		    echo "[stop] stop $BASE_PATH/$SERVER_NAME success."
		    break
		fi
	done

	if [ -n "$PID" ]; then
	    echo "[stop] $BASE_PATH/$SERVER_NAME failed, forced kill -9 $PID"
	    kill -9 $PID
	fi
    else
	echo "[stop] $BASE_PATH/$SERVER_NAME is not started, no need to stop."
    fi
}

function start() {
    echo "[start] start $BASE_PATH/$SERVER_NAME"
    echo "[start] JAVA_OPS: $JAVA_OPS"
    echo "[start] JAVA_AGENT: $JAVA_AGENT"
    echo "[start] PROFILES: $PROFILES_ACTIVE"

    BUILD_ID=dontKillMe nohup java -server $JAVA_OPS $JAVA_AGENT -jar $BASE_PATH/$SERVER_NAME.jar --spring.profiles.active=$PROFILES_ACTIVE > nohup.out 2>&1 &
    echo "[start] start $BASE_PATH/$SERVER_NAME complete."
}

function healthCheck() {
    if [ -n "$HEALTH_CHECK_URL" ]; then
	echo "[healthCheck] start a health check at $HEALTH_CHECK_URL"
	for ((i = 0; i < 120; i++))
	    do
		result=`curl -I -m 10 -o /dev/null -s -w %{http_code} $HEALTH_CHECK_URL || echo "000"`
		if [ "$result" == "200" ]; then
		    echo "[healthCheck] health check passed."
		    break
		else
		    echo -e ".\c"
		    sleep 1
		fi
	    done
	
	if [ ! "$result" == "200" ]; then
	    echo "[healthCheck] if the health check fails, the deployment may fail. check the log to determine whether the  startup is successful."
	    tail -n 10 nohup.out
	    exit 1;
	fi
    else
	echo "[healthCheck] HEALTH_CHECK_URL is not configured, start sleeping for 120s"
	sleep 120
	echo "[healthCheck] sleep for 120s, check the log and judge whether the startup is successful"
	tail -n 50 nohup.out
    fi
}

function deploy() {
    cd $BASE_PATH
    stop
    start
    healthCheck
}

deploy
